import React from "react";
import Layout from "../../components/Layout";

export default function ManagerDashboard() {
  return (
    <Layout>
      <div style={{ padding: "24px" }}>
        <h1 style={{ color: "#FF4040" }}>Manager Dashboard</h1>
        <p>Placeholder content for the Manager dashboard.</p>
      </div>
    </Layout>
  );
}

