import React from "react";
import Layout from "../../components/Layout";

export default function TechsDashboard() {
  return (
    <Layout>
      <div style={{ padding: "24px" }}>
        <h1 style={{ color: "#FF4040" }}>Technicians Dashboard</h1>
        <p>Placeholder content for the Techs dashboard.</p>
      </div>
    </Layout>
  );
}
